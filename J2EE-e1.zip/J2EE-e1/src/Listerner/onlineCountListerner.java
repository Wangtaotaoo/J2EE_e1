package Listerner;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import javax.servlet.http.HttpSessionBindingEvent;

@WebListener()
public class onlineCountListerner implements
        HttpSessionListener {


    // -------------------------------------------------------
    // HttpSessionListener implementation
    // -------------------------------------------------------
    public void sessionCreated(HttpSessionEvent se) {//设置当前的在线人数
        System.out.println("SessionCreated");
        String current = (String) se.getSession().getServletContext().getAttribute("online");
        if(current==null){current="0";}
        int count = Integer.parseInt(current);
        count++;
        current =String.valueOf(count);
        System.out.println("当前在线人数:SessionCreated"+current);
        se.getSession().getServletContext().setAttribute("online",current);
        System.out.println(se.getSession().getId());
    }

    //下线
    public void sessionDestroyed(HttpSessionEvent se) {
        String current = (String)se.getSession().getServletContext().getAttribute("online");
        if(current==null){current="0";}
            int count = Integer.parseInt(current);
            count--;
            current =String.valueOf(count);
            System.out.println("当前在线人数:sessionDestroy"+current);
            se.getSession().getServletContext().setAttribute("online",current);
    }


}
