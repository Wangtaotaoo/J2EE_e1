package util;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.IOException;
import java.util.ArrayList;

public class GetAndSend {
    private ArrayList<String> s = new ArrayList<>();
    public void setS(String str){
        s.add(str);
    }
    public ArrayList<String> getS(){
        return s;
    }

    public int getSize(){
        return s.size();
    }

}
