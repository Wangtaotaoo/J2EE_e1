package servlet;

import com.sun.org.apache.xml.internal.serialize.LineSeparator;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * zhuda
 * 2018/11/22
 */
@WebServlet(name = "LoginServlet")
public class LoginServlet extends HttpServlet {

    private List<String> userList = new ArrayList<>();
    private List<String> passwordList = new ArrayList<>();
    private boolean isLogin;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        userList.add("zd");userList.add("wt");userList.add("wsd");userList.add("lzy");userList.add("ztq");
        passwordList.add("1");passwordList.add("2");passwordList.add("3");passwordList.add("4");passwordList.add("5");

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String save_box = request.getParameter("save_password");

        String usernameTemp = "";
        String passwordTemp = "";

        System.out.println(username + "\n" + password);

        //将用户名写入Session
        request.getSession().setAttribute("nameSession", username);

        isLogin = false;

        for (int i = 0; i < 5; i++) {
            usernameTemp = userList.get(i);
            passwordTemp = passwordList.get(i);
            System.out.println(usernameTemp + "\n" + passwordTemp);

            if (usernameTemp.equals(username) && passwordTemp.equals(password)) {
                isLogin = true;
            }
        }

        System.out.println(isLogin);

        if (isLogin) {
            if ("save".equals(save_box)) {
                Cookie nameCookie = new Cookie("username", username);
                nameCookie.setMaxAge(86400 * 7);
                Cookie passwordCookie = new Cookie("password", password);
                passwordCookie.setMaxAge(86400 * 7);
                response.addCookie(nameCookie);
                response.addCookie(passwordCookie);
                System.out.println("写入Cookies:" + username + " " + password + " "+ nameCookie + " " +passwordCookie);
            }
            System.out.println("登陆成功");
            request.getRequestDispatcher("succeed.jsp").forward(request, response);
        } else {
            request.getRequestDispatcher("failed.jsp").forward(request,response);
            System.out.println("登陆失败");
        }
    }

}
